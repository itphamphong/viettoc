# jquery.wysiwygEditor
Simple jQuery HTML5 WYSIWYG editor

Demo - [here](http://pierzchalatomasz.github.io/jquery.wysiwygEditor)
